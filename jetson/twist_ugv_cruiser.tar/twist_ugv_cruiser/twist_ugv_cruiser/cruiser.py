import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
import serial
import time
#import board
#import busio
#import adafruit_pca9685
#from adafruit_motor import motor

# Constants
SERIAL_PORT = '/dev/ttyACM1'  # Modify this to your serial port
BAUD_RATE = 9600  # Baud rate for serial communication
STOP_DELAY = 0.5  # Delay in seconds before sending the stop command


class UGVCruiser(Node):
    def __init__(self):
        super().__init__('twist_ugv_cruiser')
        self.subscription = self.create_subscription(
            Twist,
            'cmd_vel',
            self.callback,
            10)
        self.get_logger().info('Twist UGV Cruiser started')

        # Set up serial communication
        self.ser = serial.Serial(SERIAL_PORT, BAUD_RATE, timeout=1)
        self.moving_forward = False  # Track if moving forward
        self.last_move_time = time.time()  # To track when we last moved

    def callback(self, msg):
        self.get_logger().info('Received Data: %s' % msg)
        
        # Extract linear velocity in the x direction
        linear_x = msg.linear.x

        # Interpret linear x direction and send commands accordingly
        if linear_x > 0:  # Forward motion
            self.move_forward()
        elif linear_x == 0 and self.moving_forward:  # Stop condition
            self.stop_robot()

    def move_forward(self):
        if not self.moving_forward:
            # Send "0x49" to serial to move forward
            self.ser.write(b'\x49')
            self.get_logger().info('Sending move command (0x49)')
            self.moving_forward = True
        self.last_move_time = time.time()  # Update the last move time

    def stop_robot(self):
        # Wait before stopping to check if the message is really stopped
        if time.time() - self.last_move_time > STOP_DELAY:
            # Send "0x6B" to serial to stop
            self.ser.write(b'\x6B')
            self.get_logger().info('Sending stop command (0x6B)')
            self.moving_forward = False

def main(args=None):
    rclpy.init(args=args)
    node = UGVCruiser()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()